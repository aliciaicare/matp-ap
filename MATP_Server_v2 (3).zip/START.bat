@echo off
echo.
echo MATP Cert App
echo ==============
echo.
set /p KEY="Paste your Anthropic API key: "
set ANTHROPIC_API_KEY=%KEY%
echo.
echo Starting at http://localhost:3000 ...
echo.
node server.js
pause
