1. Install Node.js from https://nodejs.org
2. Double-click START.bat
3. Paste your Anthropic API key
4. Open http://localhost:3000
5. Share http://YOUR-IP:3000 with team
